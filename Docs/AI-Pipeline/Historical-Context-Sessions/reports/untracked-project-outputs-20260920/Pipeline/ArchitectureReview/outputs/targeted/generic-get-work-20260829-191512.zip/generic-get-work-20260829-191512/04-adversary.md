I've now read the brief and inspected the live code paths end to end. Below is the adversarial review. Every claim cites the file and line I verified at commit `131cc63`.

---

# Adversarial QA review: generic get-work dispatcher for No Safe Circle

Scope inspected: `run_pipeline_agent.py`, `Start-GameTaskAgent.ps1`, `generic_selection.py`, `durable_selection.py`, `issue_queue.py`, `issue_workflow.py`, `issue_workflow_store.py`, `completed_issue_guard.py`, `real_workflow.py`, `real_observation.py`, `production_pipeline.py`, `openai_pipeline.py`, `goal_loop_guard.py`, `resumable_checkout.py`, `durable_checkout.py`/`real_checkout.py`, `issue_state_action.py`, `taskcontrol.py`, `execution_authority.py`, `current_conformance.py`, `persistent_work_graph.py`, `RESOURCE_GROUPS.yaml`, representative `Tasks/NSC-*.yaml`, the workflow docs, and the full `tests/` tree.

Headline: the append-only event chain is a good **detector** of concurrent writes, but the repository has **no linearization point anywhere** — every claim step is read-then-write against GitHub Issues — and several documented safety properties are either unenforced, dead code, or actively falsified by the code. One finding (the handoff template fabricating a human PASS) is a live correctness bug independent of any future dispatcher.

## Highest-risk failure modes

**1. The agent's own handoff comment parses as a human PASS result (fabricated validation).**
`publish_human_handoff` posts a comment containing the literal template lines `Result: PASS` and ``Tested commit: `{head_commit}` `` inside a ```` ```text ```` block (`issue_workflow_store.py:571-576`). `HUMAN_RESULT_RE` is a multiline/DOTALL regex with no awareness of code fences (`issue_workflow.py:34-37`), so `parse_human_validation_result(handoff_comment)` returns PASS with exactly the handoff commit. The GitHub Action takes the **latest matching comment** (`issue_state_action.py:37-45,105-118`); if the human applies `nsc-state:agent-ready` without posting a result — or posts a slightly malformed FAIL that doesn't match the regex — the Action falls back to the agent's own template and records `HUMAN_VALIDATION_PASSED`, and it passes the `tested_commit == human_handoff_commit` transition check (`issue_workflow.py:793-797`). The tested-commit binding, meant to be the strongest guarantee, becomes the attack. `ProductionTaskController.latest_human_feedback` (`production_pipeline.py:333-344`) has the identical false positive. A label mis-click routes an unvalidated build into `delivery_evidence`.

**2. Lease acquisition is read-then-write with verify-after-write; the doc's "fails closed" claim understates the damage.**
`acquire_agent_lease` does `find` → `add_comment` → `update_issue` → re-`find` verify (`issue_workflow_store.py:419-506`). `ISSUE_WORKFLOW_STATE_MACHINE.md:218` claims a two-agent race "fails closed" via duplicate sequences. True — but the failure is **permanent poisoning**: once two `agent_lease_acquired` comments with the same `sequence` exist, `validate_event_chain` rejects duplicates forever (`issue_workflow.py:896-899`), the snapshot is invalid, `observe` returns `conflict`, and `list_agent_ready` (guarded form) silently drops the Issue (`completed_issue_guard.py:96-110`). No code path can repair it: the service cannot delete comments, and no chain-repair tool exists. Worse, in the interleaving *W1-comment / W1-body / W1-verify-OK / W2-comment / W2-body*, W1 has already "acquired" and started work while the durable record now names W2 and the chain is broken — W1's very next `observe()` stalls mid-checkout. "Fails closed" here means "bricks the task and possibly strands a half-prepared checkout."

**3. Duplicate Issue creation has no guard at all.**
`_initialize_issue` is `find` → `create_issue` (`issue_workflow_store.py:384-391`). Two workers dispatched to the same fresh task both see `None` and both create. Thereafter `find` raises "multiple open GitHub Issues match" (`issue_workflow_store.py:270-274`) for **every** future run. GitHub Issue creation cannot be conditional; this path can never be a claim primitive.

**4. The generic path deletes the resource-conflict and contract-staleness checks it appears to have.**
`generic_selection.py:20` and `_managed_issue_phase` (`run_pipeline_agent.py:125-129`) and the GitHub Action (`issue_state_action.py:97-99`) all inject a stub task loader returning `"exclusive_resources": []`. Meanwhile `durable_selection.select_agent_ready_issue` — the only selector that verifies `task_contract_sha256` against the committed contract — is dead code: nothing imports it (grep confirms only its own definition). So the live resume path can select an Issue whose contract has since been revised, and only fails later, deep inside lease acquisition (`issue_workflow_store.py:428-431`), with no candidate retry.

**5. The exclusive-resource check is check-then-act across Issues and skips exactly the Issues most likely to hold resources.**
`_resource_conflicts` scans other Issues **before** writing the lease and never re-verifies after (`issue_workflow_store.py:325-359,415-417`). Two workers claiming NSC-013 and NSC-014 (both reserving `logical:enemy-locomotion-behavior-surface`, `RESOURCE_GROUPS.yaml:14-23`, `Tasks/NSC-013.yaml:19-21`) concurrently each see no conflict and both succeed — overlapping exclusive resources with two valid leases and no invariant violated anywhere. Additionally, invalid snapshots are skipped (`issue_workflow_store.py:335`), so an Issue poisoned by failure mode 2 stops reserving its resources while its worker may still be pushing to its branch.

**6. `execution_authority` is not wired into the acquisition path — explicit `-TaskId` bypasses dispatch policy entirely.**
`require_execution_authorization` is called only from `taskcontrol authorize` and its smoke test (grep: `taskcontrol.py:237`, `phase1_execution_authority_smoke_test.py`). `-TaskId` → `RealTaskReviewWorkflow` → `acquire_agent_lease` initializes an Issue and takes a lease for any active/concrete/conformant-deps task (`real_workflow.py:128-143`) with no WIP limit, no priority policy, no authorization gate. The brief's statement "execution_authority currently denies every autonomous dispatch" is true only because no code asks it. A dispatcher built on this substrate inherits an override that is a full policy bypass, not a scoped escape hatch.

**7. Completed-task resurrection protection is a 1000-item pagination window away from silently failing.**
The guard replaces `list_issues` with `gh issue list --state all --limit 1000` (`completed_issue_guard.py:75-93`), newest-first, no pagination. Closed Issues accumulate monotonically; once total Issues exceed 1000, the **oldest closed COMPLETE Issues fall out of the window first**, and `_completed_aware_candidates` reverts to exactly the resurrection bug the module's own docstring describes (`completed_issue_guard.py:1-12`). Also note the entire durable behavior of the system is nine monkey-patch layers installed by import side effect with documented ordering constraints (`__init__.py:26-45`) — auditable by no one, and one refactor away from an entry point that skips a guard.

**8. Priority does not exist; issue-number ordering is already product priority.**
No task contract has a priority field (grep across `Tasks/` finds none) and `list_agent_ready` sorts by `issue_number` (`issue_workflow_store.py:700`), i.e., Issue-creation order. `select_agent_ready_task` takes `ready[0]` (`generic_selection.py:29`). The brief forbids exactly this. There is no committed priority source anywhere to build on; a dispatcher needs a new committed policy file, not a lookup.

## Race interleavings

Concrete interleavings a dispatcher must survive, with the current outcome:

- **R1 — Two workers, one agent-ready Issue.** Both call `select_agent_ready_task`; both deterministically get `ready[0]` (`generic_selection.py:29`) — collision is *guaranteed*, not incidental. Loser (clean case) gets lease status `blocked` → `_terminal_outcome` → exit; there is no retry-next-candidate loop anywhere in `run_pipeline_agent.py`. Operator goal #3 ("two copies receive different tasks") fails even without corruption.
- **R2 — Both pass the `AGENT_READY` check before either writes.** Both post seq-n+1 comments → permanent chain corruption (failure mode 2). Sub-interleavings: both verifies fail (task bricked, nobody works it); or first verify passes and the winner is later stranded.
- **R3 — Fresh task, no Issue.** Both `find→None`, both `create_issue` → permanent multi-match brick (failure mode 3).
- **R4 — Different tasks, shared exclusive resource.** Both `_resource_conflicts` reads precede both lease writes → both leases granted (failure mode 5).
- **R5 — Label read-modify-write vs. the GitHub Action.** `GhIssueBackend.update_issue` diffs labels from a `_view_issue` read then applies add/remove (`issue_workflow_store.py:927-945`); the Action concurrently does `restore_state_label` (`issue_state_action.py:93`). Interleaved, an Issue can end with zero or two state labels → snapshot invalid → silently invisible to the queue (`issue_workflow_store.py:224-230`).
- **R6 — Human applies `agent-ready` label while a worker holds the lease body.** The Action reads the **event payload's** stale body (`issue_state_action.py:83`), not current state; decisions race against body edits made after label application.
- **R7 — Contract or main advances between selection and lease.** Selection carries no contract hash (failure mode 4); `real_observation` never fetches — `origin_main` is the last-fetched ref (`real_observation.py:193-204`) and eligibility never compares HEAD to remote main. The stale-main check that exists (`real_checkout.py:377-378`) compares two possibly-equally-stale local values; the real remote is consulted only at clone time (`real_checkout.py:423-429`), *after* the lease was recorded with a stale `source_head`.

## Authority and identity attacks

- **A1 — Event comments have no author verification.** `parse_events` accepts any comment body containing a well-formed event block (`issue_workflow.py:872-888`); `get_comments` doesn't even fetch the author field (`issue_workflow_store.py:844-860`). `event_id` is `semantic_sha256` of public fields — anyone can compute it. On a public repo, any GitHub account that can comment can append a hash-valid event. Best case it desynchronizes `state_version` vs. event count and bricks the Issue (DoS on any task, including `agent_working` ones); the actor strings inside events (`actor_type: human`) are pure self-report.
- **A2 — Task-marker aliasing.** Any Issue whose body quotes `<!-- no-safe-circle-task: NSC-021 -->` or whose title is `NSC-021 — anything` becomes a find-candidate (`issue_workflow_store.py:135-152`) → multi-match → task bricked until the spam Issue is closed. Drive-by deniable DoS on a public repo.
- **A3 — Worker identity is ephemeral and self-asserted.** Default `worker_id` embeds a fresh `uuid4` per invocation (`run_pipeline_agent.py:64-69`, `Start-GameTaskAgent.ps1:45-48`). Lease ownership checks compare this string (`goal_loop_guard.py:163`, `issue_workflow_store.py:432`). Consequence: a crashed worker's lease can never be resumed or released by any subsequent invocation (see Recovery), while conversely any process that *guesses/copies* the string inherits full lease authority.
- **A4 — Label-only transition fabricates human authority** (failure mode 1). The one transition that is supposed to require a human artifact (the validation comment) can be satisfied by the agent's own template.
- **A5 — The explicit `-TaskId` override is unbounded** (failure mode 6): no authorization gate, no WIP cap, no reason recorded, indistinguishable in the durable record from policy-approved dispatch.

## Recovery failures

Against the brief's required boundaries:

- **Candidate selected, claim not won:** worker exits with terminal `blocked`, exit 0 (`openai_pipeline.py:179-191`, `run_pipeline_agent.py:305-306`); no retry of the next candidate. Racing variant permanently poisons the Issue (R2).
- **Claim won, Issue not created / Issue created, lease not acquired:** interrupting `acquire_agent_lease` between `add_comment` and `update_issue` (crash, or GitHub 5xx on the second call — a *partial outage* is enough) leaves event-count ≠ `state_version` → Issue invalid forever. No body-rebuild-from-events repair tool exists.
- **Lease acquired, checkout not created:** the only automated release is the checkout circuit breaker, and it works only within the *same process and worker_id* (`goal_loop_guard.py:148-166`).
- **Process crash:** Issue stays `agent_working` with a dead worker's uuid. Next run generates a new uuid → `agent_working_by_other` → nothing in the codebase can release it. Leases have no TTL, no heartbeat, no takeover event type. Orphan claims are permanent absent manual GitHub surgery — which itself cannot produce a valid chain, because a hand-edited body won't match the event history.
- **Stale/orphan branch:** branch names are deterministic (`branch_name`, `real_checkout.py:105-106`), which is good for claims but means a re-dispatched task after an abandoned attempt collides with the leftover remote branch; no reconciliation policy exists for a remote task branch whose commits are not in the recorded lineage.
- **Zero eligible work:** exit 2 with a STOP message (`generic_selection.py:25-28`, `run_pipeline_agent.py:307-323`) — the same exit code as "gh not installed," "GitHub down," and every contract error. A supervisor loop cannot distinguish "idle" from "broken."
- **Completed/abandoned tasks:** protected only by the pagination-fragile guard (failure mode 7); closed non-COMPLETE Issues are ignored as candidates (`completed_issue_guard.py:69-70`), so an abandoned task's history is invisible to the next dispatcher rather than being a consulted record.
- **Misleading success exits:** `_outcome_status` defaults to `"succeeded"` when the outcome dict lacks a status (`run_pipeline_agent.py:144-149`), and `main` returns 0 for `blocked`/`needs_human` outcomes. `issue_queue.py` exits 0 for an empty queue. `Start-GameTaskAgent.ps1` only distinguishes zero/nonzero.

## Observability requirements

Evidence rule: for every safety property claimed below, the property must be demonstrated by a recorded artifact, not by code reading.

1. **Every dispatch attempt must emit a durable receipt** (JSON on disk under the output root, and an Issue/coordination event when a claim was attempted): worker_id, PID, host, policy file hash, candidate list with per-candidate exclusion reason, claim target, claim result (`won|lost|error`), and the exact remote ref/commit that decided it.
2. **Queue-drop visibility:** any Issue skipped as invalid by `list_agent_ready`/`_snapshot` must be *reported* (issue number + reasons) in the selection output, never silently omitted (today: `completed_issue_guard.py:102-103`, `issue_workflow_store.py:692`). An invisible poisoned Issue is how split work goes unnoticed.
3. **Distinct exit codes**, machine-readable: `0` work completed to a legitimate boundary (handoff published), and separate codes for *no eligible work*, *policy disabled*, *all candidates blocked (deps/resources/WIP)*, *claim lost after retries*, *invalid durable state found* (needs human), *infrastructure error*. Today 0/2 conflate all of these.
4. **Chain-integrity telemetry:** a read-only `doctor` command that walks every managed Issue, validates the event chain, and lists poisoned/orphaned/label-drifted Issues with age. Orphan leases must become visible within one run, not when a human wonders why a task stalled.
5. **Truncation alarms:** any `gh issue list` result of exactly the limit must be a hard error, not a working set (`issue_workflow_store.py:834-835`, `completed_issue_guard.py:87-88`).
6. **Priority provenance:** the selection receipt must name the committed policy file + hash that ordered the candidates, so "why this task" is answerable from artifacts.

## Mandatory negative tests

All must be deterministic (use `MemoryIssueBackend`-style backends with injectable interleaving hooks, plus real two-process tests against a local bare Git remote for the ref claim). None exist today — grep for `race|concurrent|split lease` across `tests/` returns nothing.

1. **Two-worker fresh-claim race from an empty Issue queue** (brief-required): two real processes, N≥2 eligible tasks → assert distinct tasks won, exactly one Issue per task, one lease per Issue, zero overlapping exclusive resources, and both exit with a success/lost-retry code — not corruption.
2. **Two-worker race on a single candidate:** exactly one wins; the loser retries and drains the queue or exits "no work"; the Issue chain remains valid afterward (regression for R2 — today this test would fail by bricking the Issue).
3. **Duplicate-Issue interleaving:** force both workers past `find→None`; assert the claim design makes the second `create` impossible or harmless, and that `find` recovers rather than raising forever (R3).
4. **Shared-resource split:** NSC-013 vs NSC-014 concurrently; assert the second claim is denied *after* the linearization point re-check (R4).
5. **Crash injection at every boundary** of the claim sequence (after candidate selection, after ref creation, after Issue create, between comment and body update, after lease before checkout): rerun the generic command with a **new** worker_id; assert deterministic adoption or release, never a permanent orphan.
6. **Handoff-template false PASS:** apply `agent-ready` label with no human comment, and with a malformed FAIL comment; assert the Action refuses (regression for failure mode 1; today both fail — the second recording a PASS).
7. **Forged event comment from a non-collaborator author:** assert it is ignored by author verification, not merely detected as chain breakage (A1).
8. **Marker-spoof Issue** containing the task marker: assert dispatch continues with the spoof reported, not bricked (A2).
9. **Stale main / stale contract:** worker with an outdated local `origin/main` and a contract revised on remote; assert the claim is denied at the linearization point with a "fetch and retry" outcome, and no lease is recorded against the stale head (R7).
10. **Pagination overflow:** backend simulating >limit Issues with the oldest closed-COMPLETE outside the window; assert hard error, not resurrection (failure mode 7).
11. **Completed and abandoned resurrection:** closed COMPLETE Issue and closed non-COMPLETE Issue; assert neither yields a fresh claim without explicit policy.
12. **Exit-code contract test:** table-driven assertion of every terminal outcome → exit code mapping, including empty queue, policy disabled, GitHub 5xx.

## Conditions that must block release

1. Any lease or fresh-claim path whose linearization point is a GitHub Issue read-then-write (labels, bodies, comments, or Issue creation). Explicitly: shipping the current `acquire_agent_lease`/`_initialize_issue` as the claim mechanism.
2. No committed, hash-verified dispatch policy file, or `execution_authority` still unwired from the actual acquisition path (an explicit `-TaskId` that skips authorization must not ship).
3. Priority still derived from Issue numbers or task IDs; no committed priority source.
4. The handoff-template/`HUMAN_RESULT_RE` false-PASS bug unfixed. This blocks release *independently of the dispatcher*.
5. No orphan-lease recovery (TTL/heartbeat/takeover) — given uuid-per-run worker IDs, a single crash currently strands a task permanently.
6. Selection paths still using the `exclusive_resources: []` stub loader, or `durable_selection`-style contract-hash verification still dead code.
7. No poisoned-Issue repair path (rebuild body from verified events, or supersede-Issue procedure) — because the race detector's failure mode *is* poisoning, shipping detection without repair ships a self-bricking system.
8. Event comments still trusted without author verification on a repo where non-agents can comment.
9. `gh issue list` truncation still silent.
10. The two-worker race suite (tests 1–5 above) absent or not run in CI.
11. Exit code 0 still emitted for blocked/failed outcomes via the `_outcome_status` default.

## Smallest design that survives the review

The smallest honest design uses the one primitive in this stack that *is* compare-and-swap: **atomic creation of a deterministic Git ref on the shared remote**. Git ref creation is atomic server-side; creating `refs/claims/<TASK-ID>` fails if it exists. No database, no Actions dispatcher, no coordination Issue (analyzed: a serialized Actions dispatcher adds an availability dependency and still needs a claim record; append-only claim election via an Issue inherits every comment-race problem documented above).

**New pieces (small):**

- `Pipeline/TaskGraph/DISPATCH_POLICY.yaml` — committed, reviewed, hash-recorded in every receipt: `enabled: true/false`, explicit ordered candidate list (or ordered priority tiers naming task IDs — a human writes priority; the graph doesn't infer it), WIP limit, and the eligibility predicate spelled out (active + implementation + single_agent + concrete + `not_delivered` **and** all `depends_on` conformant per `taskcontrol state` at the claim commit + no resource overlap + no existing workflow/branch state). This is where "`not_delivered` alone is not readiness" becomes enforceable, and where `require_execution_authorization` finally gets called (flip `execution_authority.py` to authorize iff the policy file authorizes, keeping deny-by-default when the file is absent or `enabled: false`).
- `Pipeline/TaskReviewAgent/fresh_claim.py` — the only new mutation code:
  1. `git fetch` the real remote; evaluate candidates at **fetched** `origin/main` (kills R7).
  2. For the first eligible candidate, atomically create `refs/claims/<TASK-ID>` pointing at the evaluated main commit via `git push origin <sha>:refs/claims/<TASK-ID>` (rejected-if-exists) with the worker_id + policy hash in a claim blob/tag message. **This is the linearization point.** Loser gets a push rejection → tries the next candidate → exits "no work" only when the ordered list is exhausted (fixes R1/R3 and gives the brief's claim-lost-retry semantics).
  3. After winning the ref, re-fetch and re-check resource overlap against *all existing claim refs* (not Issues) — claim refs are the resource registry, closing R4 with a check *after* the linearization point.
  4. Only then create/initialize the Issue and lease, recording the claim ref SHA in the lease event. Issue state becomes a *mirror* for humans; the ref is the authority, so Issue write races can no longer mint authority.
  5. Recovery is now deterministic at every boundary: a claim ref without an Issue, or a lease without progress, is adoptable/releasable by policy (age threshold recorded in `DISPATCH_POLICY.yaml`); deleting a claim ref is the single, atomic release. Completion deletes the ref; a COMPLETE Issue plus absent ref is the terminal shape, and resurrection requires recreating a ref — one auditable act.

**Existing code, minimal edits:** route generic selection through `durable_selection.select_agent_ready_issue` (resurrect the dead hash-checking code) with the real `_load_committed_task` loader instead of the `[]` stub; fix `HUMAN_RESULT_RE` to ignore fenced blocks and require the result comment's author ≠ the handoff author; make worker_id stable per machine (drop the per-run uuid or persist it); map exit codes per the observability section; hard-error on `gh` list truncation.

Everything else — the event chain, the state machine, isolated checkouts, human validation, downstream pipeline — stays as-is; the event chain's duplicate detection becomes a true invariant check (it should never fire) instead of the concurrency mechanism it is being asked to be today.
